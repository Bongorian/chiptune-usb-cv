# 部品ライブラリ・資料の出典

基板にはKiCad標準ライブラリを基にしたフットプリントと、本プロジェクト用の端子対応・配置を使用しています。
KiCad由来のライブラリに関する条件は[KiCadライブラリの案内](https://www.kicad.org/libraries/license/)を参照してください。

LCSC/EasyEDAの部品図は、実装座標の照合に使用した技術資料です。
取得元は `outputs/assembly-review/Supplier_Pad_References.json` と部品番号のリンクに記録しています。

ファームウェアのSDK・USBスタック・Cランタイムの依存関係とライセンスは[`firmware/DEPENDENCIES.md`](firmware/DEPENDENCIES.md)と[`firmware/LICENSES/`](firmware/LICENSES/)に記録しています。
